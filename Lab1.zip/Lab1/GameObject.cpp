#include "GameObject.h"
#include <cmath>
#ifndef M_PI
#define M_PI (3.14159265358979323846)
#endif

GameObject::GameObject()
{
	active = true;
}

void GameObject::draw(Mesh *mesh)
{
	mesh->draw();
}

void GameObject::setActive(bool set)
{
	active = set;
}

void GameObject::update(Mesh* mesh)
{
	mesh->updateSphereData(*tObject.GetPos(), 7.0f);
}

void GameObject::transformPositions(glm::vec3 pos, glm::vec3 rot, glm::vec3 scale)
{
	tObject.SetPos(pos);
	tObject.SetRot(rot);
	tObject.SetScale(scale);
	
}

void GameObject::setTargetPosition(glm::vec3 newPos, glm::vec3 newRot)
{
	targetPos = newPos;
	targetRot = newRot;
}

float GameObject::randomFloat()
{
    return static_cast<float>(rand()) / static_cast<float>(RAND_MAX) * 2.0f - 1.0f;
}

void GameObject::wander(GameObject object)
{
    // Generate a random point within the wander circle
    float wanderAngle = randomFloat() * 2.0f * static_cast<float>(M_PI);
    float wanderX = wanderRadius * cos(wanderAngle);
    float wanderY = wanderRadius * sin(wanderAngle);

    object.velocityX += wanderX;
    object.velocityY += wanderY;

    float length = std::sqrt(object.velocityX * object.velocityX + object.velocityY * object.velocityY);
    if (length > 0) {
        object.velocityX /= length;
        object.velocityY /= length;
    }
}

void GameObject::RotateShip()
{
    glPushMatrix();
    glTranslatef(0, 1, 0);
    glRotatef(10, 0, 0, 1);
    glPopMatrix();
}


