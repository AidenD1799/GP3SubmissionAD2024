#pragma once

#include "Mesh.h"
#include "transform.h"
#include "Shader.h"
#include <cmath>



class GameObject
{

public:
	GameObject();
	void transformPositions(glm::vec3 pos, glm::vec3 rot, glm::vec3 scale);
	void update(Mesh* mesh);
	void draw(Mesh* mesh);
	void setActive(bool set);
	
	void setTargetPosition(glm::vec3 newPos, glm::vec3 newRot);
	void wander(GameObject object);
	float randomFloat();


	bool getActive() { return active; }
	glm::mat4 getModel() { return tObject.GetModel(); }
	Transform getTM() { return tObject; }

	inline glm::vec3 GetPos() { return pos; } //getters
	inline glm::vec3 GetRot() { return rot; }
	inline glm::vec3 GetScale() { return scale; }

	inline void SetPos(glm::vec3& pos) { this->pos = pos; } // setters
	inline void SetRot(glm::vec3& rot) { this->rot = rot; }
	inline void SetScale(glm::vec3& scale) { this->scale = scale; }

	void MoveDown(float amt)
	{
		pos -= up * amt;
	}

	void MoveUp(float amt)
	{
		pos += up * amt;
	}

	void RotateShip();
	

	

	glm::vec3 pos;
	glm::vec3 rot;
	glm::vec3 scale;
	glm::vec3 forward;
	glm::vec3 up;

	glm::vec3 targetPos;
	glm::vec3 targetRot;

	float velocityX = 0.0f;
	float velocityY = 0.0f;
	const float wanderRadius = 200.0f;


private:
	Transform tObject;
	Camera cameraIn;
	Shader shaderIn;
	
	bool active;
	float counter = 0.0f;

	float deltaTime;




};


