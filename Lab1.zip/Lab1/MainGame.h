#pragma once
#include <SDL\SDL.h>
#include <GL/glew.h>
#include "Display.h" 
#include "Shader.h"
#include "Mesh.h"
#include "Texture.h"
#include "transform.h"
#include "Audio.h"
#include "SkyBox.h"
#include "GameObject.h"
#include "Audio.h"


enum class GameState{PLAY, EXIT};

class MainGame
{
public:
	MainGame();
	~MainGame();

	void run();

private:

	void initSystems();
	void processInput();
	void gameLoop();
	void drawGame();
	void linkFogShader();
	void linkToon();
	void linkRimLighting();
	void linkGeo();
	void linkEmapping();
	void linkShipShader();
	void linkGoldShader();

	void drawSkyBox();
	void drawAsteriods();
	void drawShip();
	void drawMissiles();

	void fireMissiles();
	void missileMovement(GameObject missile);

	void initModels(GameObject*& asteroid);
	bool collision(glm::vec3 m1Pos, float m1Rad, glm::vec3 m2Pos, float m2Rad);

	void moveCamera();
	void updateDelta();

	void createScreenQuad();

	void generateFBO(float w, float h);
	void bindFBO();
	void unbindFBO();
	void renderFBO();

	void updateObjectPosition(float time);

	void playAudio(unsigned int Source, glm::vec3 pos);

	void newKeyboardInput(const Uint8* keyBoard);

	void switchCamera(unsigned int cam);

	void switchShip(unsigned int shipNumber);

	void switchTexture(unsigned int textureNumber);

	Display _gameDisplay;
	GameState _gameState;
	Mesh rockMesh;
	Mesh shipMesh;
	Mesh secondShipMesh;
	Mesh missileMesh;

	Camera myCamera;
	Camera chaseCam;
	Camera rotatingCam;
	Shader fogShader;
	Shader toonShader;
	Shader rimShader;
	Shader geoShader;
	Shader shaderSkybox;
	Shader eMapping;
	Shader FBOShader;
	Shader shipShader;
	Shader goldShader;

	Transform transform;
	GameObject* asteroid = new GameObject[20];
	GameObject* missiles = new GameObject[20];
	GameObject ship;
	Texture texture;

	GLuint FBO;
	GLuint RBO;
	GLuint CBO;

	GLuint quadVAO;
	GLuint quadVBO;


	glm::vec3 currentCamPos;

	Skybox skybox;

	vector<std::string> faces;
	
	Audio audioDevice;
	bool look = true;
	float counter;
	unsigned int missileSound;
	unsigned int backGroundMusic;
	unsigned int collisionSound;

	Uint64 NOW = SDL_GetPerformanceCounter();
	Uint64 LAST = 0;
	float deltaTime = 0;

	const float mass = 1.0f;

	// Define variables for the object's velocity, and acceleration
	
	float velocityX = 0.005f;
	float velocityY = 0.005f;
	float accelerationX = 0.0005f;
	float accelerationY = 0.0005f;
	const float appliedForce = 0.001f;

	bool missileFiring = false;
	unsigned int missileCount = 0;
	float shipRot;

	bool defaultCamActive = true;
	bool chaseCamActive = false;
	bool rotatingCamActive = false;
	bool rotatingSwitch = true;

	bool firstShipActive = true;
	bool secondShipActive = false;

	unsigned int shipNumber = 2;
};

